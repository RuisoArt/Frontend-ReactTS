class Profile{
    public _id: string;
    public profileName: string;
    public profileState: number;
    public cantidadUsuarios?: number;

    constructor(id:string, name: string, state: number) {
        this._id = id;
        this.profileName = name;
        this.profileState = state;
    }
}

export default Profile;
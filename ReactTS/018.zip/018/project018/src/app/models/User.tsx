import Profile from "./Profile";

class User{
    public _id: string;
    public estadoUsuario: number;
    public fechaUsuario: Date;
    public idProfile: Profile;
    public nombreImagenUsuario: string;
    public avatarUsuario: string;

    public nameUser: string;
    public emailUser: string;
    public passUser: string;

    constructor(id: string, fec: Date, est: number, nomi: string, ava: string, codp: Profile, name: string, email: string, pass: string){
        this._id = id;
        this.fechaUsuario = fec;
        this.estadoUsuario = est;
        this.nombreImagenUsuario = nomi;
        this.avatarUsuario = ava;
        this.idProfile = codp;

        this.nameUser = name;
        this.emailUser = email;
        this.passUser = pass;
    }
}

export default User;
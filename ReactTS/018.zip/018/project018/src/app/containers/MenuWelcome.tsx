
export const MenuWelcome =()=>{
    return(
        <main id="main" className="main">
            <p>Welcome</p>
            <p>Iniciaste secion</p>
        </main>
    );
};
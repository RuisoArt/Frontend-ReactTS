Aqui se ponen cada una de las diferentes partes que componen una pagina.
el header, menu right,menu left, footer, fotos,navar, etc.
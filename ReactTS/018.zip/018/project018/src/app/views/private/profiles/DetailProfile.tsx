export const DetailProfile = ()=> {
    return(
        <main id="main" className="">
            
        </main>
    )
}

export const AboutUs = () => {
  return (
    
      <main id="main" className="main">
        About Us ALV :v
      </main>

  );
};

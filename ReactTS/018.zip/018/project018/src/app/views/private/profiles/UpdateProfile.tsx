
import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";

import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

import { ToastContainer } from "react-toastify";

import Perfil from "../../../models/Profile";
import ApiBack from "../../../utilities/domains/ApiBack";
import ServicioPrivado from "../../../services/PrivateService";
import { useFormulario } from "../../../utilities/hooks/useFormulario";
import { MensajeToastify } from "../../../utilities/functions/MensajeToastify";

export const UpdateProfile = ()=> {
    // Variables
  let { codigo } = useParams();
  type formaHtml = React.FormEvent<HTMLFormElement>;
  const [enProceso, setEnProceso] = useState<boolean>(false);
  const [todoListo, setTodoListo] = useState<boolean>(false);
  let cargaFinalizada = todoListo !== undefined;
  let { profileName, profileState, doubleLink, object } =
    useFormulario<Perfil>(new Perfil("", "", 0));

    // Consultar datos del perfil a modificar
    // *******************************************************************
    const obtenerUnPerfil = async () => {
        const urlCargarUnPerfil = ApiBack.GETONE_PRIVATE_PROFILE + "/" + codigo;
        const perfilRecibido = await ServicioPrivado.petitionGET(
          urlCargarUnPerfil
        );
        object._id = perfilRecibido._id;
        object.profileName = perfilRecibido.profileName;
        object.profileState = perfilRecibido.profileState;
        if (perfilRecibido) {
          setTodoListo(true);
        }
      };
    

      // Actualizar el perfil
  // *******************************************************************
  const enviarFormulario = async (fh: formaHtml) => {
    fh.preventDefault();
    setEnProceso(true);
    const formulario = fh.currentTarget;
    formulario.classList.add("was-validated");

    if (formulario.checkValidity() === false) {
      fh.preventDefault();
      fh.stopPropagation();
    } else {
      const urlActualizar = ApiBack.F5_PRIVATE_PROFILE + "/" + object._id;
      const resultado = await ServicioPrivado.petitionPUT(
        urlActualizar,
        object
      );

      if (resultado.after) {
        setEnProceso(false);
        MensajeToastify("success", "Perfil actualizado correctamente", 6000);
      } else {
        MensajeToastify(
          "error",
          "No se puede actualizar el perfil. Es posible que el nombre ya exista en la base de datos",
          6000
        );
      }
    }
  };

  // Hook de react que se usa cuando se renderiza o pinta la página (vista)
  useEffect(() => {
    obtenerUnPerfil();
  }, []);

    return(
        <main id="main" className="main">
      {/* Navegación estilo breadcrumb: Inicio */}
      <div className="pagetitle">
        <h1>Perfiles</h1>
        <nav>
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <Link to="/home">Inicio</Link>
            </li>
            <li className="breadcrumb-item">
              <Link to="/home/admprofile">Administración de perfiles</Link>
            </li>
            <li className="breadcrumb-item active">Actualizar</li>
          </ol>
        </nav>
      </div>
      {/* Navegación estilo breadcrumb: Fin */}

      {/* Ejemplo de furmulario: Inicio */}
      <div className="col-lg-12">
        <div className="card">
          <div className="card-body">
            <h5 className="card-title">Formulario de edición</h5>
            {cargaFinalizada ? (
              <Form
                noValidate
                validated={enProceso}
                onSubmit={enviarFormulario}
              >
                <Form.Group as={Row} className="mb-3" controlId="profileName">
                  <Form.Label column sm={2}>
                    Nombre perfil
                  </Form.Label>
                  <Col sm={10}>
                    <Form.Control
                      required
                      type="text"
                      name="profileName"
                      className="form-control"
                      value={profileName}
                      onChange={doubleLink}
                    />
                    <Form.Control.Feedback type="invalid">
                      Nombre del perfil es obligatorio
                    </Form.Control.Feedback>
                  </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="profileState">
                  <Form.Label column sm={2}>
                    Estado perfil
                  </Form.Label>
                  <Col sm={10}>
                    <Form.Select
                      required
                      name="profileState"
                      value={profileState}
                      onChange={doubleLink}
                    >
                      <option value={1}>Activo</option>
                      <option value={2}>Inactivo</option>
                    </Form.Select>
                    <Form.Control.Feedback type="invalid">
                      Seleccione el estado del perfil
                    </Form.Control.Feedback>
                  </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3">
                  <Col sm={{ span: 10, offset: 2 }}>
                    <Button type="submit" className="btn btn-sm">
                      Actualizar perfil
                    </Button>
                  </Col>
                </Form.Group>
              </Form>
            ) : (
              <div>Cargando información para la edición</div>
            )}
          </div>
        </div>
      </div>
      {/* Ejemplo de furmulario: Fin */}

      {/* Requerido para presentar los mensajes Toast: Inicio */}
      <ToastContainer />
      {/* Requerido para presentar los mensajes Toast: Fin */}
    </main>
    )
}

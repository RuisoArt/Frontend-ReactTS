import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

import Usuario from "../../../models/User";
import ApiBack from "../../../utilities/domains/ApiBack";
import noFoto from "../../../../assets/image/acercade.png";
import ServicioPrivado from "../../../services/PrivateService";
import {
  obtenerFechaLocal,
  obtenerHora,
} from "../../../utilities/functions/FormatoFecha";

export const DetailUser = () => {
  let { codigo } = useParams();
  const regresar = useNavigate();
  const [todoListo, setTodoListo] = useState<boolean>(false);
  let cargaFinalizada = todoListo !== undefined;
  const [objUsuario, setObjUsuario] = useState<Usuario>();

  useEffect(() => {
    const obtenerUnUsuario = async () => {
      const urlCargarUnUsuario = ApiBack.USUARIOS_OBTENER_UNO + "/" + codigo;
      const usuRecibido = await ServicioPrivado.petitionGET(urlCargarUnUsuario);
      if (usuRecibido) {
        setObjUsuario(usuRecibido);
        setTodoListo(true);
      }
    };
    obtenerUnUsuario();
  }, [codigo]);

  return (
    <main id="main" className="main">
      {cargaFinalizada ? (
        <div className="d-flex justify-content-center">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">Información del usuario</div>
              <div className="card-body">
                <h5 className="card-title">Nombre: {objUsuario?.nameUser}</h5>
                <p className="card-text">
                  Correo: {objUsuario?.emailUser}
                  <br />
                  Perfil: {objUsuario?.idProfile.profileName}
                  <br />
                  Fecha creación:{" "}
                  {obtenerFechaLocal(String(objUsuario?.fechaUsuario))}
                  <br />
                  Hora creación: {obtenerHora(String(objUsuario?.fechaUsuario))}
                  <br />
                  Estado:
                  <span
                    className={
                      objUsuario?.estadoUsuario === 1
                        ? "text-success"
                        : "text-danger"
                    }
                  >
                    {objUsuario?.estadoUsuario === 1 ? "Activo" : "Inactivo"}
                  </span>
                  <br />
                  Nombre avatar: {objUsuario?.nombreImagenUsuario}
                  <br />
                  <img
                    onError={({ currentTarget }) => {
                      currentTarget.onerror = null;
                      currentTarget.src = noFoto;
                    }}
                    src={objUsuario?.avatarUsuario}
                    alt="Profile"
                    className="maximoTamanoCreacion"
                  />
                </p>
              </div>
              <div className="card-footer">
                <button
                  onClick={() => regresar(-1)}
                  className="btn btn-info btn-sm"
                >
                  Regresar
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div>Carga de usuario en proceso</div>
      )}
    </main>
  );
};

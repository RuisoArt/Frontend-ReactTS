import { lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { MenuWelcome } from "../../containers/MenuWelcome";
import { AdminProfile } from "../../views/private/profiles/AdminProfile";
import { ListProfile } from "../../views/private/profiles/ListProfile";

import { NewProfile } from "../../views/private/profiles/NewProfile";
import { ListAvion } from "../../views/private/avion/ListAvion";
import { NewAvion } from "../../views/private/avion/NewAvion";
import { AboutUs } from "../../views/private/users/AboutUs";
import { NotFound } from "../../views/share/NotFound";
import { UpdateProfile } from "../../views/private/profiles/UpdateProfile";
import { DetailProfile } from "../../views/private/profiles/DetailProfile";
import { ListUser } from "../../views/private/users/ListUser";
import { AdminUser } from "../../views/private/users/AdminUser";
import { NewUser } from "../../views/private/users/NewUser";
import { CurrentUser } from "../../views/private/users/UpdateUser";
import { DetailUser } from "../../views/private/users/DetailUser";

//ruta peresoza (importa ubicacion).(la promesa de lo que importas)
const LazyAboutUs = lazy(()=> import ("../../views/private/users/AboutUs").then(()=>({default: AboutUs})) );
const LazyNotFound = lazy(()=> import ("../../views/share/NotFound").then(()=>({default: NotFound})));
const LazyMenuWelcome = lazy(()=> import ("../../containers/MenuWelcome").then(()=>({default: MenuWelcome})));

const LazyListProfile = lazy(()=> import ("../../views/private/profiles/ListProfile").then(()=>({default: ListProfile})));
const LazyAdminProfile = lazy(()=> import ("../../views/private/profiles/AdminProfile").then(()=>({default: AdminProfile})));
const LazyNewProfile = lazy(()=> import ("../../views/private/profiles/NewProfile").then(()=>({default: NewProfile})) ); 
const LazyCurrentProfile = lazy(()=> import ("../../views/private/profiles/UpdateProfile").then(()=>({default: UpdateProfile}))); 
const LazyDetailProfile = lazy(()=> import ("../../views/private/profiles/DetailProfile").then(()=>({default: DetailProfile})) ); 

const LazyListUser = lazy(()=> import ("../../views/private/users/ListUser").then(()=>({default: ListUser})));
const LazyAdminUser = lazy(()=> import ("../../views/private/users/AdminUser").then(()=>({default: AdminUser})));
const LazyNewUser = lazy(()=> import ("../../views/private/users/NewUser").then(()=>({default: NewUser})) ); 
const LazyCurrentUser = lazy(()=> import ("../../views/private/users/UpdateUser").then(()=>({default: CurrentUser}))); 
const LazyDetailUser = lazy(()=> import ("../../views/private/users/DetailUser").then(()=>({default: DetailUser})) ); 

const LazyListAvion = lazy(()=> import ("../../views/private/avion/ListAvion").then(()=>({default: ListAvion})));
const LazyNewAvion = lazy(()=> import ("../../views/private/avion/NewAvion").then(()=>({default: NewAvion})) );

export const PrivateRouting = () =>{
    return(
        <Routes>
            <Route path = "/" element={<LazyMenuWelcome/>}/>
            <Route path = "/aboutUs" element={<LazyAboutUs/>}/>
            <Route path = "*" element={<LazyNotFound/>}/>

            <Route path = "/listProfile" element={<LazyListProfile/>}/>
            <Route path = "/adminProfile" element={<LazyAdminProfile/>}/>
            <Route path = "/newProfile" element={<LazyNewProfile/>}/>
            <Route path = "/currentProfile/:codigo" element={<LazyCurrentProfile/>}/>
            <Route path = "/detailProfile/:codigo" element={<LazyDetailProfile/>}/>

            <Route path = "/listUser" element={<LazyListUser/>}/>
            <Route path = "/adminUser" element={<LazyAdminUser/>}/>
            <Route path = "/newUser" element={<LazyNewUser/>}/>
            <Route path = "/currentUser/:codigo" element={<LazyCurrentUser/>}/>
            <Route path = "/detailUser/:codigo" element={<LazyDetailUser/>}/>

            <Route path = "/listAvion" element={<LazyListAvion/>}/>
            <Route path = "/newAvion" element={<LazyNewAvion/>}/>

        </Routes>
    );
};
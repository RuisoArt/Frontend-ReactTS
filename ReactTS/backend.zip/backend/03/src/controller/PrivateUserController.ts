import { Request, Response } from 'express';
import PrivateUserDao from '../dao/PrivateUserDao';


class PrivateUserController extends PrivateUserDao {

    public crear(req: Request, res: Response): void {
        const emailUser = { emailUser: req.body.emailUser };
        PrivateUserController.crearUsuario(emailUser, req.body, res);
    }

    public consulta(req: Request, res: Response): void {
        PrivateUserController.obtenerUsuarios(res);
    }

    public consultaUno(req: Request, res: Response): void {
        PrivateUserController.obtenerUnUsuario(req.params.codigo, res);
    }

    public eliminar(req: Request, res: Response): void {
        PrivateUserController.eliminarUsuario(req.params.codUsuario, res);
    }

    public actualizar(req: Request, res: Response): void {
        PrivateUserController.actualizarUsuario(req.params.codUsuario, req.body, res);
    }

    public cantidadEnPerfil(req: Request, res: Response): void {
        PrivateUserController.cantidadUsuariosEnPerfil(req.params.codPerfil, res);
    }

    public consultaXPerfil(req: Request, res: Response): void {
        PrivateUserController.obtenerUsuariosPerfil(req.params.codPerfil, res);
    }

};

const privateUserController = new PrivateUserController();
export default privateUserController;
import { Router } from "express";
import PrivateUserController from "../controller/PrivateUserController";

class UserPrivateRoute {

    public rutaAPI: Router;

    constructor() {
        this.rutaAPI = Router();
        this.configuracion();
    }

    public configuracion(): void {
        this.rutaAPI.post('/crear', PrivateUserController.crear);

        this.rutaAPI.get('/todos', PrivateUserController.consulta);
        this.rutaAPI.get('/uno/:codigo', PrivateUserController.consultaUno);

        this.rutaAPI.get('/todos/:codPerfil', PrivateUserController.consultaXPerfil);
        this.rutaAPI.get('/cantxperfil/:codPerfil', PrivateUserController.cantidadEnPerfil);

        this.rutaAPI.delete('/eliminar/:codUsuario', PrivateUserController.eliminar);
        this.rutaAPI.put('/actualizar/:codUsuario', PrivateUserController.actualizar);
    }

};

const userPrivateRoute = new UserPrivateRoute();
export default userPrivateRoute.rutaAPI;

import Server from './setting/Server';

const myServer = new Server();
myServer.initBackend();